# This shows the minimal modification needed to abstract_eval.py
# to support configurable pooling

def load_model(self):
    """
    Loads the model using the specified class and keyword arguments.
    Converts model to the specified dtype and device.
    """
    if self.model_class.__name__ == "SentenceTransformer":
        # Check if we need to create a custom pooling configuration
        pooling_mode = self.model_kwargs.pop('pooling_mode', None)
        
        if pooling_mode:
            # Create SentenceTransformer with specific pooling
            from sentence_transformers import models
            
            # Create Transformer module
            model_path = self.model_kwargs.pop('model_name_or_path')
            transformer = models.Transformer(
                model_name_or_path=model_path,
                max_seq_length=self.max_length or 512,
                model_args={"trust_remote_code": True},
                tokenizer_args={"trust_remote_code": True}
            )
            
            # Create Pooling module with specified mode
            pooling = models.Pooling(
                word_embedding_dimension=transformer.get_word_embedding_dimension(),
                pooling_mode=pooling_mode  # "lasttoken", "mean", "cls", etc.
            )
            
            # Create SentenceTransformer with modules
            self.model = self.model_class(modules=[transformer, pooling])
        else:
            # Use default SentenceTransformer loading
            self.model = self.model_class(**self.model_kwargs)
    else:
        self.model = self.model_class.from_pretrained(**self.model_kwargs)
    
    self.model = self.model.to(self.model_dtype).to(self.device)
